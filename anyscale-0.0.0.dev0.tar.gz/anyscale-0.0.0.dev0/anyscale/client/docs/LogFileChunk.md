# LogFileChunk

When we retrieve log file chunks from a cloud storage bucket, we infer properties about the chunks using a combination of (a) the filename/path, and (b) the chunk labels/metadata. We pass this metadata down to the client, so the client can group/categorize/process chunks as needed.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cluster_id** | **str** | The cluster ID that this file originates from. | 
**chunk_name** | **str** | The full object name of a chunk (e.g. .../dashboard_agent.log/chunk-one.log) | 
**chunk_url** | **str** | A presigned URL to download this chunk. | 
**size** | **int** | The size of this chunk (should never exceed 10MB). | 
**file_name** | **str** | The full file name (path) of a file (e.g. .../dashboard_agent.log | 
**node_type** | [**NodeType**](NodeType.md) | The type of node that this file originated from (e.g. head-node, worker-nodes | 
**node_ip** | **str** | The node IP that this file originated from. | 
**instance_id** | **str** | The instance ID that this file originated from. | 
**session_id** | **str** | The session ID that this file originated from. | 
**ray_pid** | **str** | The PID that this file originated from, if appropriate. | [optional] 
**ray_worker_id** | **str** | The Ray worker ID that this file originated from, if appropriate. | [optional] 
**job_id** | **str** | The Ray job ID that this file originated from, if appropriate. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


