# TimestampedLogsOutput

This logs output type is used to model logs, such as from Loki, where timestamp_ns is used to support pagination.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lines** | **list[str]** |  | 
**last_timestamp_ns** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


