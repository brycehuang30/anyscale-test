# AwsRegionAndZones

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**regions** | [**dict(str, AwsRegionInfo)**](AwsRegionInfo.md) | A map of region names to a list of availability zones for that region. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


