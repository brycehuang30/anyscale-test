# DecoratedServiceEventAPIModel

This class should be inherited and should not be used directly
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Id of the service event | 
**created_at** | **datetime** | The last time the state of this job was updated. This includes updates to the state and to the goal state | 
**event_type** | [**ServiceEventType**](ServiceEventType.md) | Type of Service Event | 
**current_state** | [**ServiceEventCurrentState**](ServiceEventCurrentState.md) | Present only for Service events. | [optional] 
**goal_state** | [**ServiceGoalStates**](ServiceGoalStates.md) | Present only for Service events. | [optional] 
**level** | [**ServiceEventLevel**](ServiceEventLevel.md) |  | [optional] 
**message** | **str** |  | [optional] 
**origin** | [**ServiceEventOrigin**](ServiceEventOrigin.md) | The origin of the service event. | 
**service_id** | **str** | The id of the Service v2. Present only for Service events. | [optional] 
**service_version_name** | **str** | The name of the associated service version. Present only for Service Version event | [optional] 
**cluster_id** | **str** | The associated cluster id.Present only for Service Version event and only when the cluster is associated with the event. | [optional] 
**goal_state_initiator** | [**MiniUser**](MiniUser.md) | The user who initiated the service goal state change. Present only for goal state changes. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


