# GCPNodeDisk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**boot** | **bool** |  | [optional] 
**auto_delete** | **bool** |  | [optional] 
**type** | **str** |  | [optional] 
**initialize_params** | [**object**](.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


