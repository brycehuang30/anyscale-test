# ArchivedLogsInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url_head** | **str** | Used to probe when logs are available on s3. | 
**url_get** | **str** | Download link for logs. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


