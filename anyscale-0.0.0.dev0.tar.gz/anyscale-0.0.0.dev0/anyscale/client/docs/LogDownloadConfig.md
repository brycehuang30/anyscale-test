# LogDownloadConfig

Configuration for listing log files.     
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**next_page_token** | **str** | The next page token (requests to the Log Download API are paginated). | [optional] 
**page_size** | **int** | Page size (default: 1000 items/page). | [optional] [default to 1000]
**ttl_seconds** | **int** | The time-to-live of the presigned url in seconds (default: 4 hours). | [optional] [default to 14400]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


