# ScheduleConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cron_expression** | **str** | A cron expression to define the frequency at which to run this cron job, for example &#39;0 0 * * *&#39; is a cron expression that means &#39;run at midnight&#39;. Visit crontab.guru to construct a precise cron_expression. | 
**timezone** | **str** | The timezone in which to interpret the cron_expression. Default is Universal time (UTC). | [optional] [default to 'Universal']

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


