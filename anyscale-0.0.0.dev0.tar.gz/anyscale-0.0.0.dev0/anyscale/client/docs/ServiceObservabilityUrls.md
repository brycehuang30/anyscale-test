# ServiceObservabilityUrls

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**service_dashboard_url** | **str** | URL that points to a dashboard with relevant graphs about the entire service. | [optional] 
**serve_deployment_dashboard_url** | **str** | URL that points to a dashboard with relevant graphs about a single deployent or replica of a service. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


