# OrganizationCollaborator

Readable fields for an organization collaborator
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**permission_level** | [**OrganizationPermissionLevel**](OrganizationPermissionLevel.md) |  | 
**id** | **str** | The identity id of the organization collaborator | 
**name** | **str** |  | 
**created_at** | **datetime** |  | 
**email** | **str** |  | 
**user_id** | **str** | The user id of the organization collaborator | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


