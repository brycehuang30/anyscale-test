# ClusterAuthResponse

Returns a URL where the token should be posted to in order to complete authentication & set the token as a cookie.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**complete_auth_url** | **str** |  | 
**token** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


