# LogDetail

Information about a log file.     
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | name of the log file. | 
**download_url** | **str** | download link for logs. | 
**size** | **int** | size of the log file. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


