# CloudProjectCollaborator

If a CloudProjectCollaborator gets permissions on a project, that project will be public within the cloud and accessible to all users in the cloud identity group.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | 
**value** | [**CloudProjectCollaboratorValue**](CloudProjectCollaboratorValue.md) |  | 
**permission_level** | [**PermissionLevel**](PermissionLevel.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


