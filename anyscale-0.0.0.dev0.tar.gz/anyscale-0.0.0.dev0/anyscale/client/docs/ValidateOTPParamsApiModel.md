# ValidateOTPParamsApiModel

POST parameters for validate_otp_token API endpoint
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**otp** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


