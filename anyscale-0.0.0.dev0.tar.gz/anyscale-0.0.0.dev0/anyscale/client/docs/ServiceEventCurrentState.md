# ServiceEventCurrentState

The possible 'current state' values for a service  These states may be shown in the UI as the primary state of the service
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


