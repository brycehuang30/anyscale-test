# CloudResourceGCP

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gcp_vpc_id** | **str** | The GCP vpc id of this cloud. | 
**gcp_subnet_ids** | **list[str]** | A list of GCP subnet IDs of this cloud. | 
**gcp_cluster_node_service_account_email** | **str** | The GCP service account email of this cloud. | 
**gcp_anyscale_iam_service_account_email** | **str** | The GCP service account email of this cloud. | 
**gcp_filestore_config** | [**GCPFileStoreConfig**](GCPFileStoreConfig.md) | The GCP filestore config of this cloud. | 
**gcp_firewall_policy_ids** | **list[str]** | A list of GCP firewall policy IDs of this cloud. | 
**gcp_cloud_storage_bucket_id** | **str** | The GCP cloud storage bucket id of this cloud. | 
**gcp_deployment_manager_id** | **str** | The GCP deployment manager id of this cloud. | [optional] 
**id** | **str** | Server assigned unique identifier. | 
**cloud_id** | **str** | The ID of the cloud that this cloud resource belongs to. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


