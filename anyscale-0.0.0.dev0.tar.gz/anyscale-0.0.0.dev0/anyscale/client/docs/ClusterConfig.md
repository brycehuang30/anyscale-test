# ClusterConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config** | **str** | The cluster configuration in JSON format. | 
**config_with_defaults** | **str** | The cluster configuration in JSON format with the defaults filled in. | 
**last_modified_at** | **datetime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


