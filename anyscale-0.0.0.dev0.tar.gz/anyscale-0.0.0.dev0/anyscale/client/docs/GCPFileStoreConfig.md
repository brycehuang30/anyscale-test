# GCPFileStoreConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instance_name** | **str** |  | 
**mount_target_ip** | **str** |  | 
**root_dir** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


