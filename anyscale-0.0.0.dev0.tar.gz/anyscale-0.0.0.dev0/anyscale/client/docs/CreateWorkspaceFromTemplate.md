# CreateWorkspaceFromTemplate

Model used to create a workspace from template
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**template_id** | **str** | The Id of the template to use. | 
**cloud_id** | **str** | The cloud id for the workspace. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


