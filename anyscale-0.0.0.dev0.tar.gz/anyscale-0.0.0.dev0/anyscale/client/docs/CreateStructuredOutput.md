# CreateStructuredOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**production_job_id** | **str** | The id of a production job.  | 
**ray_job_submission_id** | **str** | The id of a ray job submission.  | 
**output** | **object** | The data of a structured output. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


